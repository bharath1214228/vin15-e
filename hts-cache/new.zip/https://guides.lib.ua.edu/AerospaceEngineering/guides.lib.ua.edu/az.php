<!-- error_screen_full.twig -->
<html lang="en">
<head>
    <title>
                    (404)
            </title>
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.css"/>
    <style>
        .s-lib-debug {
            font-family: verdana;
            font-size: 11px;
            color: #fff;
        }
    </style>
</head>

<body>
<!-- error_screen.twig -->
<div style="width:80%; max-width:800px; text-align:center; margin:0px auto; color:#bbb; font-family:Tahoma;">
            <div style="font-size:12em; font-size:12vw;">
        <span class="fa-stack">
            <i class="fa fa-stack-2x fa-square-o"></i>
            <i class="fa fa-stack-1x fa-hand-stop-o"></i>
        </span>
        </div>
                <div class="header">
            <h1>The requested page could not be found</h1>
        </div>
                <div class="content">
            This could be because the link you clicked was not formed properly or because the page has been deleted.
                            <div class="link">
                    <a href="/">Home</a><span style="padding:0 20px;">|</span><a href="srch.php">Search</a>
                </div>
                    </div>
    </div>
<style>
    div.header {
        padding: 10px;
    }

    div.header h1 {
        font-size: 1.4em;
    }

    div.content {
        padding: 10px;
        font-size: 1.2em;
    }

    div.link {
        padding: 20px;
        font-size: 0.8em;
    }
</style>
<!-- !error_screen.twig -->

</body>
</html>
<!-- error_screen_full.twig -->
